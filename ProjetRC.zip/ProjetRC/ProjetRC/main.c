#include <stdio.h>
#include "partieHeuristique.h"
#include "jouer.h"

int main(int argc, const char * argv[])
{
    //partiH();
    jouer();
    return 0;
}
