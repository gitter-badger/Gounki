//
//  test.h
//  Projet
//
//  Created by Etienne Toussaint on 07/04/2014.
//  Copyright (c) 2014 Etienne Toussaint. All rights reserved.
//

#ifndef Projet_test_h
#define Projet_test_h

void initMap();
void freeMap();
void affiche();
void updateMap(pion ** grille);

#endif
